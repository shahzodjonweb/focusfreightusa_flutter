import 'package:flutter/material.dart';
import '../widgets/mainpage_widget.dart';
import 'myaccount_screen.dart';
import 'test_screen.dart';


class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MainPage();
  }
}